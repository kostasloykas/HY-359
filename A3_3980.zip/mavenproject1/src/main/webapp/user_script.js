/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */



//ok
function logout(){
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        window.location.href="./Login_form.html";        
    } else if (xhr.status !== 200) {
        alert('Request failed. Returned status of ' + xhr.status);
    }
    };
    xhr.open('POST', 'Logout');
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
}


var current_email;

function req_show_data(){
    if(document.getElementById("form-info").hidden===false) {
        $('#form-info').hide();
        document.getElementById("form-info").hidden=true;
        $('#save-butt').hide();
        return 0;
    }
    
    
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        const data = JSON.parse(xhr.responseText);
        var gender=data.gender;

        current_email=data.email;
        document.getElementById("Username").value=data.username;
        document.getElementById("E-mail").value=data.email;
        document.getElementById("Password").value=data.password;
        document.getElementById("Name").value=data.firstname;
        document.getElementById("last-name").value=data.lastname;
        document.getElementById("date").value=data.birthdate;
        document.getElementById(gender.toString()).checked = true;
        document.getElementById("AMKA").value=data.amka;
        document.getElementById("country").value=data.country;
        document.getElementById("City").value=data.city;
        document.getElementById("Address").value=data.address;
        document.getElementById("Phone-number").value=data.telephone;
        document.getElementById("height").value=data.height;
        document.getElementById("weight").value=data.weight;
        document.getElementById("height").value=data.height;
        document.getElementById("Blood-type").value=data.bloodtype;
        
        var blooddonor=data.blooddonor;
        if(blooddonor=="1") document.getElementById("blooddonoryes").checked=true;
        else document.getElementById("blooddonorno").checked=true;



        
        $('#form-info').show();
        document.getElementById("form-info").hidden=false;
        $('#save-butt').show();
    } else if (xhr.status !== 200) {
        alert('Request failed. Returned status of ' + xhr.status);
    }
    };
    xhr.open('GET', 'servlet_user_data');
    xhr.send();
    
}


var flag_email=1;
function check_email(){
    var data = $("#form-info").serialize();
    
    if(document.getElementById("E-mail").value===current_email){
        document.getElementById("msg-email").innerText="";
        flag_email=1;
        return 0;
    }
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        if (xhttp.readyState === 4 && xhttp.status === 200) {
            flag_email=1;
            document.getElementById("msg-email").innerText="";
        }else if(xhttp.status === 403){
            flag_email=0;
            document.getElementById("msg-email").innerText="Υπαρχει ηδη αυτο το email";
        } 
    };
    xhttp.open("POST","servlet_email");
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send(data);
}


function save_data(){
        console.log("sdf");

    if(flag_email==0){
        document.getElementById("msg-email").innerText="Μη εγκυρο email";
        return 0;
    }
    console.log("perase");
    let myForm = document.getElementById("form-info");
    let formData = new FormData(myForm);
    const data = {};
    formData.forEach((value, key) => (data[key] = value));
    var jsonData=JSON.stringify(data);
    
    console.log(jsonData);

    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("msg-submit").innerHTML="Οι αλλαγες αποθηκευτηκαν επιτυχως";
            setTimeout(function(){
                document.getElementById("msg-submit").innerHTML = '';
            }, 1500);
        } else if (xhr.status !== 200) {
            console.log("Request failed. Returned status of " + xhr.status + "<br>");
        }
    };
    
    xhr.open("PUT", "update_user");
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.send(jsonData);
    
    
}














//ok
function req_list_doctors(){
    
    if(document.getElementById("doctor_list").hidden===false) {
        $('#doctor_list').hide();
        document.getElementById("doctor_list").hidden=true;
        $('#save-butt').hide();
        return 0;
    }
    
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        const responseData = JSON.parse(xhr.responseText);
        $('#doctor_list').html(createTableFromJSON(responseData)); 
        $('#doctor_list').show();
        document.getElementById("doctor_list").hidden=false;
        
    } else if (xhr.status !== 200) {
        alert('Request failed. Returned status of ' + xhr.status);
    }
    };
    xhr.open('GET', 'servlet_print_doctors');
    xhr.send();
    
    
}


//ok
function createTableFromJSON(data) {
    html="<table id='doctor-table'><tr><th>Ονομα</th><th>Επώνυμο</th><th>Διεύθυνση</th><th>Πόλη</th><th>Πληροφορίες</th><th>Ειδικότητα</th><th>Τηλέφωνο</th></tr>";
//    console.log(data);
    for (const x in data) {
        var firstname=data[x].firstname;
        var lastname=data[x].lastname;
        var address=data[x].address;
        var city=data[x].city;
        var doctor_info=data[x].doctor_info;
        var specialty=data[x].specialty;
        var telephone=data[x].telephone;
        
        html += "<tr><td>" + firstname + "</td><td>" + lastname + "</td><td>" + address + "</td><td>" + city + "</td><td>" + doctor_info +  "</td><td>" + specialty + "</td><td>" + telephone +  "</td></tr>";
    }
    html += "</table>";
    return html;
}


//ok
function health(){
    
    const xhr = new XMLHttpRequest();
    xhr.onload = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        const data = JSON.parse(xhr.responseText);
        var birthdate = new Date(data.birthdate);
        var age=2021 - birthdate.getFullYear();
        var weight=data.weight;
        var height=data.height;
        var gender=data.gender;
        
        console.log(age,weight,height,gender);
        if( age===null || data.weight===null || data.heigth===null || data.gender===null) {
            document.getElementById("msg-health").style.color="red";
            document.getElementById("msg-health").innerHTML="Δεν εχετε δηλωσει ολα τα στοιχεια για αυτην την επιλογη";
            return;
        }
        req_bmi(age,weight,height);
        ideal_weight(gender,height);
    } else if (xhr.status !== 200) {
        alert('Request failed. Returned status of ' + xhr.status);
    }
    };
    xhr.open('GET', 'servlet_health');
    xhr.send();

    
}

//ok
function req_bmi(age,weight,height){
    if(document.getElementById("health").hidden===false) {
        $('#health').hide();
        document.getElementById("health").hidden=true;
        $('#health').hide();
        return 0;
    }
    
    const data = null;
    const xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
            if (this.readyState === this.DONE) {
                    var data=JSON.parse(this.responseText);
                    var bmi=data.data.bmi;
                    var health=data.data.health;
                    document.getElementById("cel1").innerHTML=bmi;
                    document.getElementById("cel2").innerHTML=health;
                    $('#health').show();
                    document.getElementById("health").hidden=false;

            }
    });

    xhr.open("GET", "https://fitness-calculator.p.rapidapi.com/bmi?age="+age+"&weight="+weight+"&height="+height);
    xhr.setRequestHeader("x-rapidapi-host", "fitness-calculator.p.rapidapi.com");
    xhr.setRequestHeader("x-rapidapi-key", "d8411a84a8mshf5884f4d72ca62fp1808a6jsna58f1b00cced");
    xhr.send(data);

}

//ok
function ideal_weight(gender,height){
    const data = null;
    if(gender=="Male") gender="male";
    if(gender=="Female") gender="female";
    if(gender=="Other") alert("User gender is Other");

    const xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
            if (this.readyState === this.DONE) {
                    var data=JSON.parse(this.responseText);
                    var devine = data.data.Devine;
                    document.getElementById("cel3").innerHTML=devine;
            }
    });

    xhr.open("GET", "https://fitness-calculator.p.rapidapi.com/idealweight?gender="+gender+"&height="+height);
    xhr.setRequestHeader("x-rapidapi-host", "fitness-calculator.p.rapidapi.com");
    xhr.setRequestHeader("x-rapidapi-key", "d8411a84a8mshf5884f4d72ca62fp1808a6jsna58f1b00cced");

    xhr.send(data);
}